<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Why Us</title>
	<meta name="description" content="">
	 <?php include('header.php') ?>
    
    <div id="why-us-course-banner" class="container-fluid px-0">
        <div class="service-inner-banner">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-12">
                        <h1 class="banner-heading">Why Us</h1>
                    </div>
                    <div class="col-md-6 col-lg-6">
                    </div>
                </div>    
            </div>
        </div>
    </div>
    
    <section id="content-main-container" class="container-xxl py-5">
        <div class="container">
            <div class="row">
                   
                <div id="content-container" class="col-lg-12 col-md-12 col-sm-12 ps-5">
                    <div class="inner-content-start">
                       
                        <h2 class="pt-3">WHY US</h2>
                        
                        
                        <p class="inner-paragraph">We only give you one good reason to pick us from the thousands online to assist you, that is, we provide you with quality delivery of what we promise with the assistance of supportive professors, consultants and experts without any negligence, and we take all the work seriously.</p> 
                        <p class="inner-paragraph">We believe we have stepped up & provided students with numerous benefits, leveraging our experience to make complex concepts simple and enjoyable to understand.</p> 
                       
                        <ul class="providing-solution-list">
                            <li><p class="inner-paragraph">We have a team of professors who are academic writers & specialised in educational content.</p></li>
                            <li><p class="inner-paragraph">They have a minimum of 15 years of experience handling every subject and guiding students in an easy manner.</p></li>
                            <li><p class="inner-paragraph">All your project is assigned and executed by our team of experts in the field.</p></li>
                            <li><p class="inner-paragraph">We concentrate on projects assigned to the subject specialist, e.g., a medical expert will handle a health assignment, and the business tutor deals with the commerce work.</p></li>
                            <li><p class="inner-paragraph">If we lack the expertise in your field or do not have an available expert, we will add a professional who is familiar with your assignment to our team.</p></li>
                            <li><p class="inner-paragraph">You can always get online guidance on the implementation of the project.</p></li>
                            <li><p class="inner-paragraph">We provide plagiarism-free content.</p></li>
                            <li><p class="inner-paragraph">We will hand over the student's assignment to our top-notch team.</p></li>
                            <li><p class="inner-paragraph">Scheduled based easy and convenient instalment plan for payment modes to suit and convenience for all scholars.</p></li>
                            <li><p class="inner-paragraph">Global consulting by country and city</p></li>

                        </ul>
                        <h2 class="pt-3">Complete Privacy</h2>
                        
                        
                        <p class="inner-paragraph">Our website is capable of keeping students' confidentiality. All assignments are done with scrutiny and privacy. The fact is, we will not share your information, like your identity, because we trust you, as our team knows now, with third parties (outsourced persons, businesses, agencies, organisations, institutes) we will not share any information. </p> 
                        <p class="inner-paragraph">Finally, you will enrol in the desired course with the assistance of our live support specialists, and any questions or doubts you will be put at ease before moving toward your education.</p> 


                        
                    </div> 
                </div>    
            </div>
        </div>
    </section>
    
    
   <?php include('footer.php') ?>  