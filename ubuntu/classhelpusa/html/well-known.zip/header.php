
	<link rel="shortcut icon" href="https://www.classhelpusa.com/assets/images/fav-icon.png">
    <link rel="stylesheet" href="https://www.classhelpusa.com/assets/css/style.css" />
    <link rel="stylesheet" href="https://www.classhelpusa.com/assets/css/responsive.css" />
   <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css?ver=6.1" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&family=Oswald:wght@200..700&display=swap" />
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>

      <!--Start of Tawk.to Script-->
            <script type="text/javascript">
            var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
            (function(){
            var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
            s1.async=true;
            s1.src='https://embed.tawk.to/67aa40743a842732607c93bf/1ijogni9d';
            s1.charset='UTF-8';
            s1.setAttribute('crossorigin','*');
            s0.parentNode.insertBefore(s1,s0);
            })();
            </script>
        <!--End of Tawk.to Script-->
        
      <!-- Google Tag Manager -->
        <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-WSQB9DQT');</script>
        <!-- End Google Tag Manager -->
        
        <!-- Google tag (gtag.js) -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-RLTVQYTZ9T"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
        
          gtag('config', 'G-RLTVQYTZ9T');
        </script>
     
      <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    
    <style>
    .navbar_display {
        align-items: center;
        display: flex;
        gap: 14px;
        justify-content: center;
    }    
        .navbar-expand-lg .navbar-nav .nav-link {
            color: var(--c1);
            transition: all 0.5s;
            font-weight: 500;
        }
    @media screen and (min-width: 992px) {
      .dropdown:hover .dropdown-menu {
        display: block;
        margin-top: 0;
      }
      .dropdown .dropdown-menu {
        display: none;
      }
      .dropdown:hover .dropdown-toggle::after {
        border-top: 0;
        border-bottom: 0.3em solid;
      }
    }
    
    @media screen and (max-width: 991px) {
      .dropdown-toggle.show::after {
        border-top: 0;
        border-bottom: 0.3em solid;
      }
    }
    
    </style>

    </head>

  <body>
      
       <!-- Google Tag Manager (noscript) -->
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WSQB9DQT"
        height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
        <!-- End Google Tag Manager (noscript) -->
        
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="row">
            <div class="col-lg-12">
                <div class="modal-side-content">
                    <div class="modal-side-content-inner-body">
                        <span>Unlock Up to</span>
                        <p>70% OFF</p>
                        <span>Your First Class!</span>
                    </div>
                    <button type="button" class="btn-close response-none" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
            </div> 
            <!--<div class="col-lg-6">-->
                <div class="modal-form">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title" id="exampleModalLabel">Sign Up Now And<br> Get A Free Class Quote</h3>
                            <div class="response-show">
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                        </div>
                        <div class="modal-paragraph">
                            <p>The Exclusive Offer won't last long - it's time to invest in your future.</p>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <form action="submit-form.php" method="post" class="contact-form">
                                      <div class="container">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="contact-form-input">
                                                  <input type="text" name="lname" placeholder="Last Name">
                                                </div>
                                                <div class="contact-form-input">
                                                  <input type="email" name="emailadd" placeholder="Email Address...">
                                                </div>
                                                <div class="contact-form-input">
                                                  <input type="tel" name="pn" placeholder="Phone No..">
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <div class="captcha">
                                                            <div class="g-recaptcha" data-sitekey="6LcNwjwlAAAAAO1BW4zH_51xiDBzZ4a8eD66Zt7P"></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="contact-form-inputs">
                                                          <input type="submit" name="sbmtbtn" value="Submit">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                          </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <header>
      <div class="upper-header">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-5"></div>
            <div class="col-lg-7">
              <div class="header-contacts responsive-none-contacts">
                <div class="our-contact-details">
                  <i class="fa-solid fa-headset"></i>
                  <a href="javascript:void(Tawk_API.toggle())" id="liveSupportLink">Live Support</a>
                </div>
                <div class="our-contact-details">
                  <i class="fa-solid fa-phone"></i>
                  <a href="tel:+14698122083">Phone</a>
                </div>
                <div class="our-contact-details">
                  <i class="far fa-alarm-clock"></i>
                  <a href="javascript:;" class="triggerModal">Quick Query</a>
                </div>
                <div class="our-contact-details">
                  <i class="far fa-envelope"></i>
                  <a href="mailto:info@classhelpusa.com">Send Email</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="lower-header">
        <div class="container">
          <div class="row">
              
              
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-light">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#">
                        <div class="logo">
                    <img src="https://www.classhelpusa.com/assets/images/Logo.png" alt="Class Help USA">
              </div></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <!-- About Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="servicesDropdown" role="button" aria-expanded="false">
                            About
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="servicesDropdown">
                             <li><a class="dropdown-item" href="https://www.classhelpusa.com/profile.php">Profile</a></li>
                            <li><a class="dropdown-item" href="https://www.classhelpusa.com/our-team.php">Our Team</a></li>
                             <li><a class="dropdown-item" href="https://www.classhelpusa.com/work-module.php">Work Module</a></li>
                            <li><a class="dropdown-item" href="https://www.classhelpusa.com/why-us.php">Why Us</a></li>
                        </ul>
                    </li>
                    <!-- Services Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="servicesDropdown" role="button" aria-expanded="false">
                            Services
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="servicesDropdown">
                            <li class="dropdown-submenu">
                                <a class="dropdown-item" href="#">Online Class Help</a>
                                <ul class="dropdown-menu submenu-dropdowns">
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/accounting-class-help.php">Accounting Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/anatomy-class-help.php">Anatomy Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/algebra-class-help.php">Algebra Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/astrophysics-class-help.php">Astrophysics Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/architecture-class-help.php">Architecture Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/astronomy-class-help.php">Astronomy Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/biomedical-class-help.php">Biomedical Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/business-class-help.php">Business Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/biology-class-help.php">Biology Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/chemistry-class-help.php">Chemistry Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/coding-class-help.php">Coding Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/calculus-class-help.php">Calculus Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/dentistry-class-help.php">Dentistry Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/data-science-class-help.php">Data Science Class Help</a></li>
                                    <li><a class="dropdown-item" class="dropdown-item" href="https://www.classhelpusa.com/economics-class-help.php">Economics Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/engineering-class-help.php">Engineering Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/english-literature-class-help.php">English Literature Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/finance-class-help.php">Finance Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/history-class-help.php">History Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/law-class-help.php">Law Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/marketing-class-help.php">Marketing Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/management-class-help.php">Management Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/medicine-class-help.php">Medicine Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/math-class-help.php">Math Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/nursing-class-help.php">Nursing Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/programming-class-help.php">Programming Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/pharmacy-class-help.php">Pharmacy Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/physics-class-help.php">Physics Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/psychology-class-help.php">Psychology Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/python-class-help.php">Python Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/science-class-help.php">Science Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/statistics-class-help.php">Statistics Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/linguistic-class-help.php">Linguistic Class Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/thermodynamics-class-help.php">Thermodynamics Class Help</a></li>           
                                </ul>
                                
                            </li>
                            <li class="dropdown-submenu">
                                <a class="dropdown-item" href="#">Online Course Help</a>
                                <ul class="dropdown-menu submenu-dropdowns">
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/edgenuity-course-help.php">Edgenuity Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/pearson-course-help.php">Pearson Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/online-course-help.php">Online Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/cpma-course-help.php">CPMA Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/sophia-course-help.php">Sophia Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/cipd-course-help.php">CIPD Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/ged-course-help.php">GED Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/gre-course-help.php">GRE Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/ati-teas-course-help.php">ATI TEAS Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/aleks-course-help.php">Aleks Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/edx-course-help.php">Edx Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/insurance-course-help.php">Insurance Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/eppp-course-help.php">EPPP Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/mpje-course-help.php">MPJE Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/neplex-course-help.php">NEPLEX Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/cisa-course-help.php">CISA Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/cism-course-help.php">CISM Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/ccsp-course-help.php">CCSP Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/six-sigma-course-help.php">Six Sigma Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/hesi-a2-course-help.php">HESI A2 Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/praxis-course-help.php">PRAXIS Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/nclex-course-help.php">NCLEX Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/phr-course-help.php">PHR Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/shrm-course-help.php">SHRM Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/cplp-course-help.php">CPLP Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/cqe-course-help.php">CQE Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/eit-course-help.php">EIT Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/fe-course-help.php">FE Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/pe-course-help.php">PE Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/cfa-course-help.php">CFA Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/csm-course-help.php">CSM Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/pmp-course-help.php">PMP Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/capm-course-help.php">CAPM Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/dele-course-help.php">DELE Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/cpt-course-help.php">CPT Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/chs-course-help.php">CHS Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/texes-course-help.php">TExES Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/cset-course-help.php">CSET Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/comlex-course-help.php">COMLEX Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/lsat-course-help.php">LSAT Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/cbap-course-help.php">CBAP Course Help</a></li>
                                    <li><a class="dropdown-item" href="https://www.classhelpusa.com/cscp-course-help.php">CSCP Course Help</a></li>
                                </ul>
                            </li>
                            <!--
                            <li class="dropdown-submenu">
                                <a class="dropdown-item" href="#">Digital Marketing</a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="#">SEO Services</a></li>
                                    <li><a class="dropdown-item" href="#">PPC Services</a></li>
                                    <li><a class="dropdown-item" href="#">Social Media Marketing</a></li>
                                </ul>
                            </li>-->
                            
                            <li><a class="dropdown-item" href="#">Online Exam Help</a></li>
                            <li><a class="dropdown-item" href="#">Take My Online Class</a></li>
                            <li><a class="dropdown-item" href="#">Take My Online Course</a></li>
                            <li><a class="dropdown-item" href="#">Online Class Professionals</a></li>
                            <li><a class="dropdown-item" href="#">Online Classroom Help</a></li>
                            <li><a class="dropdown-item" href="#">University Class Help</a></li>
                            <li><a class="dropdown-item" href="#">College Course Help</a></li>
                            
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Countries</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="https://www.classhelpusa.com/blog.php">Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="https://www.classhelpusa.com/contact-us.php">Contact Us</a>
                    </li>
                </ul>
            </div>
                </div>
            </nav>
            
          </div>
        </div>
      </div>
      
    </header>